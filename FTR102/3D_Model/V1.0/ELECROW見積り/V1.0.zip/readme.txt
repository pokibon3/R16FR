SIZE:73mmx43mm
Thickness:2mm
Color:Transpearent
